package com.bram;

public class kiloBytes {
        double answer = pMK(1453.23);
        private static double pMK(double kiloBytes)
        {
            long megaBytes=Math.round(kiloBytes/1000);
            double remainder=kiloBytes-(megaBytes*1000);
            System.out.println(kiloBytes+" KB = "+megaBytes+"MB and"+remainder+" KB");
        }
    }

