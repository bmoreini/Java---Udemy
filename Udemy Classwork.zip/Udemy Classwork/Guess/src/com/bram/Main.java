
/* NOTE: Add Play Again option using nested method */

package com.bram;
import java.util.Random;
import java.util.Scanner;

import static java.lang.System.out;

public class Main {
    public static void main(String[] args) {
        /* Note: a void method is also known as a procedure */
        int answer = getAnswer();
        int turns = 0;
        Scanner reader = new Scanner(System.in);
        boolean gameOver = false;
        do {
            turns ++;
            int guess=getGuess(reader);
            gameOver = checkGuess(guess,answer);
        }
        while (!gameOver);
        reader.close();
        out.println("You won in " + turns + " turns!");
        }

    private static int getAnswer() {
        /* generate random number function - a non-void method is a function */
        Random rand = new Random();
        int answer;
        answer = rand.nextInt(100) + 1;
        out.println(answer);
        return answer;
    }

    private static int getGuess(Scanner reader) {
        /* scan and read guess */
        out.println("Enter a guess: ");
        return reader.nextInt();
    }

    private static boolean checkGuess(int guess, int answer) {
        /* compare guess with answer */
        if (guess == answer) {
            return true;
        }
        else {
            if (guess < answer) out.println("too low!");
            else out.println("too high");
            return false;
        }
    }
}
