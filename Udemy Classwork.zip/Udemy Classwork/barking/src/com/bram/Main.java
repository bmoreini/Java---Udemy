package com.bram;

public class Main {

    public static void main(String[] args) {
    }
    public static boolean main ( boolean barking, int hourOfDay){
            if ((hourOfDay >= 0) && (hourOfDay <= 23) && (barking == true)) {
                if ((hourOfDay < 8) || (hourOfDay > 22)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

