package com.bram;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String myString = "This is my string"; // Note CAPITAL LETTER!
        myString = myString + ", and this is more";
        System.out.println(myString);
    }
}
