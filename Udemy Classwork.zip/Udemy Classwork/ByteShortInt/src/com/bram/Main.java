package com.bram;

import java.sql.SQLOutput;

public class Main {
// The public keyword is an access specifier, which allows the programmer to control the visibility of class members.
    public static void main(String[] args) {
// When a class member is preceded by public, then that member can be accessed by code outside the class in which it is declared.
// In this case, main( ) must be declared as public, since it must be called by code outside of its class when the program is started.
// The keyword static allows main( ) to be called without having to instantiate a particular instance of the class.
// This is necessary since main( ) is called by the Java interpreter before any objects are made.
// The keyword void simply tells the compiler that main( ) does not return a value. As you will see, methods may also return values.
// As stated, main( ) is the method called when a Java application begins. Keep in mind that Java is case-sensitive.
// Thus, Main is different from main. It is important to understand that the Java compiler will compile classes that do not contain a
// main( ) method. But the Java interpreter has no way to run these classes. So, if you had typed Main instead of main,
// the compiler would still compile your program. However, the Java interpreter would report an error because it would be unable to
// find the main( ) method.
// Any information that you need to pass to a method is received by variables specified within the set of parentheses
// that follow the name of the method. These variables are called parameters. If there are no parameters required for a given method,
// you still need to include the empty parentheses. In main( ), there is only one parameter, albeit a complicated one.
// String args[ ] declares a parameter named args, which is an array of instances of the class String.
// Objects of type String store character strings. In this case, args receives any command-line arguments present when the program
// is executed.
	    // datatypes based on whole numbers
        long myLongValue = 100L ; // width of 64
        int myValue = 10_000; // literal - width of 32
        short myShortValue = 32_767; // medium - width of 16
        byte myByteValue; // less storage - width of 8
        myByteValue = 123; // split expressions from creations
        int myNewByteValue = (myByteValue/2); // assignments need to be int
        byte myNewestByteValue = (byte) (myByteValue/2); // convert to byte via casting
        System.out.println (myNewestByteValue); //sout + tab
        System.out.printf ("something");//souf + tab
    }
}
