package com.bram;

public class Main {

    public static void main(String[] args) {
	// write your code here
        char myName = 'B';
        char myName2 = '\u00a9'; // unicode-table.com/en/#control-character
        System.out.println(myName2);
        boolean myBoolean = true;
    }
}
