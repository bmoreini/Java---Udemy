public class hello {
    public static void main(String [] args) {
        System.out.println("Hello, World!");
        int myFirstNumber = 5;
        System.out.println(myFirstNumber);
    }
}
